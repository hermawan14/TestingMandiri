(function(window, undefined) {

  var jimLinks = {
    "6a20f9b9-1544-4281-a58e-158c54c157ec" : {
      "Ellipse_2" : [
        "51bd79fd-58ac-4a35-bec7-995f3bf300bd"
      ],
      "Path_4" : [
        "51bd79fd-58ac-4a35-bec7-995f3bf300bd"
      ],
      "Paragraph_6" : [
        "51bd79fd-58ac-4a35-bec7-995f3bf300bd"
      ],
      "Ellipse_3" : [
        "483c72c8-603d-449b-b9c7-ada32fb7b620"
      ],
      "Path_7" : [
        "483c72c8-603d-449b-b9c7-ada32fb7b620"
      ],
      "Paragraph_7" : [
        "483c72c8-603d-449b-b9c7-ada32fb7b620"
      ],
      "Path_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_3" : [
        "6a20f9b9-1544-4281-a58e-158c54c157ec"
      ]
    },
    "0034d58b-0d89-4f39-960a-6f0094edbf72" : {
      "Path_17" : [
        "6a20f9b9-1544-4281-a58e-158c54c157ec"
      ],
      "Path_7" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_31" : [
        "6a20f9b9-1544-4281-a58e-158c54c157ec"
      ],
      "Button_2" : [
        "0034d58b-0d89-4f39-960a-6f0094edbf72"
      ],
      "Label_45" : [
        "51bd79fd-58ac-4a35-bec7-995f3bf300bd"
      ]
    },
    "483c72c8-603d-449b-b9c7-ada32fb7b620" : {
      "Path_1" : [
        "6a20f9b9-1544-4281-a58e-158c54c157ec"
      ],
      "Path_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_3" : [
        "6a20f9b9-1544-4281-a58e-158c54c157ec"
      ]
    },
    "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506" : {
      "Panel_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_10" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_54" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "6a20f9b9-1544-4281-a58e-158c54c157ec"
      ],
      "Paragraph_2" : [
        "0f768f9a-1be8-4d4e-8043-412168b625b2"
      ]
    },
    "51bd79fd-58ac-4a35-bec7-995f3bf300bd" : {
      "Button_2" : [
        "0034d58b-0d89-4f39-960a-6f0094edbf72"
      ],
      "Path_17" : [
        "6a20f9b9-1544-4281-a58e-158c54c157ec"
      ],
      "Path_7" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_31" : [
        "6a20f9b9-1544-4281-a58e-158c54c157ec"
      ]
    },
    "0f768f9a-1be8-4d4e-8043-412168b625b2" : {
      "Panel_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_10" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_54" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);