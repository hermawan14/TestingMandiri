	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Image", "6a20f9b9-1544-4281-a58e-158c54c157ec"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "6a20f9b9-1544-4281-a58e-158c54c157ec"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_63", "6a20f9b9-1544-4281-a58e-158c54c157ec"]] = ""; 

			widgets.rootWidgetMap[["s-Path_63", "6a20f9b9-1544-4281-a58e-158c54c157ec"]] = ["Person", "s-Path_63"]; 

	widgets.descriptionMap[["s-Path_4", "6a20f9b9-1544-4281-a58e-158c54c157ec"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "6a20f9b9-1544-4281-a58e-158c54c157ec"]] = ["Bag", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_7", "6a20f9b9-1544-4281-a58e-158c54c157ec"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "6a20f9b9-1544-4281-a58e-158c54c157ec"]] = ["Check mark diamond", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_2", "6a20f9b9-1544-4281-a58e-158c54c157ec"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "6a20f9b9-1544-4281-a58e-158c54c157ec"]] = ["Logout", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "6a20f9b9-1544-4281-a58e-158c54c157ec"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "6a20f9b9-1544-4281-a58e-158c54c157ec"]] = ["Home", "s-Path_3"]; 

	widgets.descriptionMap[["s-Image", "0034d58b-0d89-4f39-960a-6f0094edbf72"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "0034d58b-0d89-4f39-960a-6f0094edbf72"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_17", "0034d58b-0d89-4f39-960a-6f0094edbf72"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "0034d58b-0d89-4f39-960a-6f0094edbf72"]] = ["Chevron left", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_7", "0034d58b-0d89-4f39-960a-6f0094edbf72"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "0034d58b-0d89-4f39-960a-6f0094edbf72"]] = ["Logout", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_31", "0034d58b-0d89-4f39-960a-6f0094edbf72"]] = ""; 

			widgets.rootWidgetMap[["s-Path_31", "0034d58b-0d89-4f39-960a-6f0094edbf72"]] = ["Home", "s-Path_31"]; 

	widgets.descriptionMap[["s-Rectangle_8", "0034d58b-0d89-4f39-960a-6f0094edbf72"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "0034d58b-0d89-4f39-960a-6f0094edbf72"]] = ["Alert single", "s-Group_16"]; 

	widgets.descriptionMap[["s-Label_45", "0034d58b-0d89-4f39-960a-6f0094edbf72"]] = ""; 

			widgets.rootWidgetMap[["s-Label_45", "0034d58b-0d89-4f39-960a-6f0094edbf72"]] = ["Button", "s-Label_45"]; 

	widgets.descriptionMap[["s-Paragraph_18", "0034d58b-0d89-4f39-960a-6f0094edbf72"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "0034d58b-0d89-4f39-960a-6f0094edbf72"]] = ["Alert single", "s-Group_16"]; 

	widgets.descriptionMap[["s-Paragraph_19", "0034d58b-0d89-4f39-960a-6f0094edbf72"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "0034d58b-0d89-4f39-960a-6f0094edbf72"]] = ["Alert single", "s-Group_16"]; 

	widgets.descriptionMap[["s-Image", "483c72c8-603d-449b-b9c7-ada32fb7b620"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "483c72c8-603d-449b-b9c7-ada32fb7b620"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_1", "483c72c8-603d-449b-b9c7-ada32fb7b620"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "483c72c8-603d-449b-b9c7-ada32fb7b620"]] = ["Chevron left", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "483c72c8-603d-449b-b9c7-ada32fb7b620"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "483c72c8-603d-449b-b9c7-ada32fb7b620"]] = ["Logout", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "483c72c8-603d-449b-b9c7-ada32fb7b620"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "483c72c8-603d-449b-b9c7-ada32fb7b620"]] = ["Home", "s-Path_3"]; 

	widgets.descriptionMap[["s-Image", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Rectangle_19", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ["Top bar 2", "s-Top_Bar-2"]; 

	widgets.descriptionMap[["s-Path_10", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ["Top bar 2", "s-Top_Bar-2"]; 

	widgets.descriptionMap[["s-Paragraph_54", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_54", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ["Top bar 2", "s-Top_Bar-2"]; 

	widgets.descriptionMap[["s-Paragraph_56", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_56", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ["Top bar 2", "s-Top_Bar-2"]; 

	widgets.descriptionMap[["s-Text_15", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ""; 

			widgets.rootWidgetMap[["s-Text_15", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ["Title Button", "s-Text_15"]; 

	widgets.descriptionMap[["s-Path_83", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ""; 

			widgets.rootWidgetMap[["s-Path_83", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ["Statuts bar", "s-statusBar_7"]; 

	widgets.descriptionMap[["s-Path_84", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ""; 

			widgets.rootWidgetMap[["s-Path_84", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ["Statuts bar", "s-statusBar_7"]; 

	widgets.descriptionMap[["s-Union_8", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ""; 

			widgets.rootWidgetMap[["s-Union_8", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ["Statuts bar", "s-statusBar_7"]; 

	widgets.descriptionMap[["s-Panel_1", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506"]] = ["Top nav default", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "51bd79fd-58ac-4a35-bec7-995f3bf300bd"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "51bd79fd-58ac-4a35-bec7-995f3bf300bd"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_17", "51bd79fd-58ac-4a35-bec7-995f3bf300bd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "51bd79fd-58ac-4a35-bec7-995f3bf300bd"]] = ["Chevron left", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_7", "51bd79fd-58ac-4a35-bec7-995f3bf300bd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "51bd79fd-58ac-4a35-bec7-995f3bf300bd"]] = ["Logout", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_31", "51bd79fd-58ac-4a35-bec7-995f3bf300bd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_31", "51bd79fd-58ac-4a35-bec7-995f3bf300bd"]] = ["Home", "s-Path_31"]; 

	widgets.descriptionMap[["s-Image", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Rectangle_19", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ["Top bar 2", "s-Top_Bar-2"]; 

	widgets.descriptionMap[["s-Path_10", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ["Top bar 2", "s-Top_Bar-2"]; 

	widgets.descriptionMap[["s-Paragraph_54", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_54", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ["Top bar 2", "s-Top_Bar-2"]; 

	widgets.descriptionMap[["s-Paragraph_56", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_56", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ["Top bar 2", "s-Top_Bar-2"]; 

	widgets.descriptionMap[["s-Text_15", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ""; 

			widgets.rootWidgetMap[["s-Text_15", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ["Title Button", "s-Text_15"]; 

	widgets.descriptionMap[["s-Path_83", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ""; 

			widgets.rootWidgetMap[["s-Path_83", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ["Statuts bar", "s-statusBar_7"]; 

	widgets.descriptionMap[["s-Path_84", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ""; 

			widgets.rootWidgetMap[["s-Path_84", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ["Statuts bar", "s-statusBar_7"]; 

	widgets.descriptionMap[["s-Union_8", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ""; 

			widgets.rootWidgetMap[["s-Union_8", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ["Statuts bar", "s-statusBar_7"]; 

	widgets.descriptionMap[["s-Panel_1", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "0f768f9a-1be8-4d4e-8043-412168b625b2"]] = ["Top nav default", "s-Dynamic_Panel_1"]; 

	