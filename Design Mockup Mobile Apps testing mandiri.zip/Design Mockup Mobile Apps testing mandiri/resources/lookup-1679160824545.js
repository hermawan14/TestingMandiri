(function(window, undefined) {
  var dictionary = {
    "6a20f9b9-1544-4281-a58e-158c54c157ec": "Screen 4",
    "0034d58b-0d89-4f39-960a-6f0094edbf72": "Screen 6",
    "483c72c8-603d-449b-b9c7-ada32fb7b620": "Screen 7",
    "dc6f2aea-13e6-4a2e-9b40-6f7976ee9506": "Screen 3",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Screen 1",
    "51bd79fd-58ac-4a35-bec7-995f3bf300bd": "Screen 5",
    "0f768f9a-1be8-4d4e-8043-412168b625b2": "Screen 2",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);