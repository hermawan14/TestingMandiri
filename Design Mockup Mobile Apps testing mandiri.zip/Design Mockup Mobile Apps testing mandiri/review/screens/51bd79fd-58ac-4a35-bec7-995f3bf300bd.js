var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1679160824545.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-51bd79fd-58ac-4a35-bec7-995f3bf300bd" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 5" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/51bd79fd-58ac-4a35-bec7-995f3bf300bd-1679160824545.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="401.0px" datasizeheight="173.0px" datasizewidthpx="401.00000000000006" datasizeheightpx="173.0" dataX="13.5" dataY="49.8" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="100.0px" datasizeheight="100.0px" dataX="33.0" dataY="85.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/a402d7e2-e8d2-48ee-b721-1ee7d17cf065.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Pinjaman"   datasizewidth="66.7px" datasizeheight="18.0px" dataX="271.9" dataY="76.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Pinjaman</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Rp. 12.000.000"   datasizewidth="109.4px" datasizeheight="18.0px" dataX="271.9" dataY="95.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Rp. 12.000.000</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Sisa Pinjaman"   datasizewidth="102.3px" datasizeheight="18.0px" dataX="271.9" dataY="136.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Sisa Pinjaman</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="Rp. 5.000.000"   datasizewidth="100.5px" datasizeheight="18.0px" dataX="271.9" dataY="156.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Rp. 5.000.000</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="History Payment"   datasizewidth="101.0px" datasizeheight="26.0px" dataX="271.9" dataY="188.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">History Payment</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable non-processed" customid="Jumlah Pinjaman"   datasizewidth="122.7px" datasizeheight="18.0px" dataX="33.0" dataY="300.2" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Jumlah Pinjaman</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="number text firer commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="33.0" dataY="331.8" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="number"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Paragraph_6" class="richtext autofit firer ie-background commentable non-processed" customid="Metode Pembayaran"   datasizewidth="148.5px" datasizeheight="18.0px" dataX="33.0" dataY="403.3" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">Metode Pembayaran</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Category_1" class="dropdown firer commentable non-processed" customid="Category 1"    datasizewidth="300.0px" datasizeheight="45.0px" dataX="31.5" dataY="432.1"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Bank Transfer</div></div></div></div></div><select id="s-Category_1-options" class="s-51bd79fd-58ac-4a35-bec7-995f3bf300bd dropdown-options" ><option selected="selected" class="option">Bank Transfer</option>\
      <option  class="option">Credit Card</option></select></div>\
      <div id="s-Paragraph_7" class="richtext autofit firer ie-background commentable non-processed" customid="Bank Account"   datasizewidth="98.7px" datasizeheight="18.0px" dataX="33.0" dataY="500.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Bank Account</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Category_2" class="dropdown firer commentable non-processed" customid="Category 2"    datasizewidth="300.0px" datasizeheight="45.0px" dataX="33.0" dataY="527.3"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Bank Mandiri</div></div></div></div></div><select id="s-Category_2-options" class="s-51bd79fd-58ac-4a35-bec7-995f3bf300bd dropdown-options" ><option selected="selected" class="option">Bank Mandiri</option>\
      <option  class="option">BRI</option>\
      <option  class="option">BNI</option></select></div>\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Buat Pengajuan"   datasizewidth="287.7px" datasizeheight="35.6px" dataX="33.0" dataY="604.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Buat Pengajuan</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_17" class="path firer click commentable non-processed" customid="Chevron left"   datasizewidth="31.4px" datasizeheight="36.0px" dataX="33.0" dataY="863.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="31.36328125" height="35.99180221557617" viewBox="33.0 863.0 31.36328125 35.99180221557617" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_17-51bd7" d="M33.0 880.9959001799534 C33.0 881.7059579505132 33.39934159901616 882.3146789051098 34.259434275558405 882.8421424037189 L58.15819742498001 898.3020564029832 C58.83378834981588 898.7482668484904 59.69391769072328 898.9917992591854 60.70782404533746 898.9917992591854 C62.73494346475199 898.9917992591854 64.36328125 897.9368722619673 64.36328125 896.5774681109815 C64.36328125 895.9080357662513 63.93304159053079 895.3196297260122 63.25745066569492 894.8528754160941 L41.723849049289555 880.9959001799534 L63.25745066569492 867.1388566990853 C63.93304159053079 866.6722179649153 64.36328125 866.063567456489 64.36328125 865.4143355510896 C64.36328125 864.0549996448311 62.73494346475199 863.0 60.70782404533746 863.0 C59.69391769072328 863.0 58.83378834981588 863.243465266689 58.15819742498001 863.6898133023725 L34.259434275558405 879.1293452432733 C33.39934159901616 879.6771236562399 33.0 880.2858424093936 33.0 880.9959001799534 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_17-51bd7" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_7" class="path firer click commentable non-processed" customid="Logout"   datasizewidth="41.2px" datasizeheight="46.9px" dataX="352.3" dataY="857.6"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="41.15625" height="46.85006332397461" viewBox="352.3046875 857.5708690302802 41.15625 46.85006332397461" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_7-51bd7" d="M357.95088195913354 904.4209302289053 L376.45307234527354 904.4209302289053 C380.17075007971295 904.4209302289053 382.09916923142686 901.9972206005768 382.09916923142686 897.3228949151926 L382.09916923142686 887.5852238385969 L378.6939979074229 887.5852238385969 L378.6939979074229 897.0633863951545 C378.6939979074229 899.0759215435444 377.84285391656135 900.1794414692572 376.15756347875606 900.1794414692572 L358.2288380253242 900.1794414692572 C356.5436670730753 900.1794414692572 355.70977902915143 899.0759215435444 355.70977902915143 897.0633863951545 L355.70977902915143 864.9283618802411 C355.70977902915143 862.9158772006533 356.5436670730753 861.8122583972875 358.2288380253242 861.8122583972875 L376.15756347875606 861.8122583972875 C377.84285391656135 861.8122583972875 378.6939979074229 862.9158772006533 378.6939979074229 864.9283618802411 L378.6939979074229 874.4281667980733 L382.09916923142686 874.4281667980733 L382.09916923142686 864.6686823842615 C382.09916923142686 860.0161690061178 380.17075007971295 857.5708690302802 376.45307234527354 857.5708690302802 L357.95088195913354 857.5708690302802 C354.23308494586024 857.5708690302802 352.3046875 860.0161690061178 352.3046875 864.6686823842615 L352.3046875 897.3228949151926 C352.3046875 901.9972206005768 354.23308494586024 904.4209302289053 357.95088195913354 904.4209302289053 Z M369.13908277983 882.9758957903616 L386.65079330551134 882.9758957903616 L389.2220166360908 882.8244770245936 L387.95379942175737 884.1660840388257 L385.36518164022164 887.1957179843096 C385.05247843004634 887.5418907071968 384.8789275199629 888.0394842558031 384.8789275199629 888.5373249985417 C384.8789275199629 889.5110906642356 385.4695516535181 890.3334375641614 386.26870743747133 890.3334375641614 C386.685582207424 890.3334375641614 386.9982887251579 890.1170191012932 387.29360079193555 889.7491777527548 L392.92250002687234 882.4997236732742 C393.32198034586867 881.9804635589678 393.4609375 881.5042893819292 393.4609375 880.9850292676228 C393.4609375 880.4657691533165 393.32198034586867 879.9895949762779 392.92250002687234 879.4703348619715 L387.29360079193555 872.1992131868152 C386.9982887251579 871.8314223070789 386.685582207424 871.6366683499597 386.26870743747133 871.6366683499597 C385.4695516535181 871.6366683499597 384.8789275199629 872.415632679659 384.8789275199629 873.4110669710038 C384.8789275199629 873.8872401180669 385.05247843004634 874.4065002323732 385.36518164022164 874.752673985236 L387.95379942175737 877.8039744964199 L389.23941108704713 879.145581510652 L386.65079330551134 878.9724941192329 L369.13908277983 878.9724941192329 C368.28774033544926 878.9724941192329 367.5581590477627 879.88150934191 367.5581590477627 880.9850292676228 C367.5581590477627 882.0885491933357 368.28774033544926 882.9758957903616 369.13908277983 882.9758957903616 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-51bd7" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_31" class="path firer click commentable non-processed" customid="Home"   datasizewidth="51.5px" datasizeheight="41.8px" dataX="188.3" dataY="860.1"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="51.49802017211914" height="41.81520080566406" viewBox="188.25098967552185 860.0882996403043 51.49802017211914 41.81520080566406" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_31-51bd7" d="M188.25098967552185 879.831131681301 C188.25098967552185 880.8469978161472 189.09314395563825 881.7259637261217 190.44059994184528 881.7259637261217 C191.0932716506591 881.7259637261217 191.68277450660392 881.3939353243419 192.20913249698418 881.0032338837165 L194.60928161889984 879.1279602249981 L194.60928161889984 897.2937650749291 C194.60928161889984 900.1844597816839 196.4830955954871 901.903499492294 199.70436670053397 901.903499492294 L228.1903507357651 901.903499492294 C231.39070948034893 901.903499492294 233.28553290886958 900.1844597816839 233.28553290886958 897.2937650749291 L233.28553290886958 879.0303950768136 L235.81204029706993 881.0032338837165 C236.31724948070053 881.3939353243419 236.90677518169718 881.7259637261217 237.5595405552236 881.7259637261217 C238.80159861021784 881.7259637261217 239.74901032447815 881.0032338837165 239.74901032447815 879.8702463340445 C239.74901032447815 879.2061895304852 239.47544539759096 878.6788082889317 238.92784036673808 878.2489943150237 L233.28553290886958 873.8346084985104 L233.28553290886958 865.5135728230341 C233.28553290886958 864.6345846587192 232.6749257940262 864.0876704645955 231.72751407976588 864.0876704645955 L228.82203926445519 864.0876704645955 C227.89570896404155 864.0876704645955 227.26402043535148 864.6345846587192 227.26402043535148 865.5135728230341 L227.26402043535148 869.1467125984103 L217.0106585741624 861.1577265193238 C215.17907710267667 859.7318241608851 212.86313027286783 859.7318241608851 211.0313089283377 861.1577265193238 L189.09314395563825 878.2489943150237 C188.52467339667868 878.6788082889317 188.25098967552185 879.26486044987 188.25098967552185 879.831131681301 Z M220.06345655984006 885.222268979917 C220.06345655984006 884.304188417199 219.4320056196892 883.7183587996657 218.44243564674582 883.7183587996657 L209.5997717287987 883.7183587996657 C208.61019947135014 883.7183587996657 207.95743181331852 884.304188417199 207.95743181331852 885.222268979917 L207.95743181331852 898.0164927978733 L200.82022640460644 898.0164927978733 C199.51486014192693 898.0164927978733 198.79904356754855 897.3326571842676 198.79904356754855 896.1021066058723 L198.79904356754855 875.866120344259 L213.09477224510604 864.7322600188756 C213.6843002306079 864.2634638585365 214.3579071449366 864.2634638585365 214.94743513043846 864.7322600188756 L229.07476036603492 875.7487763860285 L229.07476036603492 896.1021066058723 C229.07476036603492 897.3326571842676 228.35875531997874 898.0164927978733 227.05345759245478 898.0164927978733 L220.06345655984006 898.0164927978733 L220.06345655984006 885.222268979917 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_31-51bd7" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_8" class="richtext autofit firer ie-background commentable non-processed" customid="PENGAJUAN PINJAMAN"   datasizewidth="188.5px" datasizeheight="18.0px" dataX="124.2" dataY="247.4" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0">PENGAJUAN PINJAMAN</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;