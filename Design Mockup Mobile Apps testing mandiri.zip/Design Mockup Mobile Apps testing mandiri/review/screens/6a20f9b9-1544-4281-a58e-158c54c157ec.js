var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1679160824545.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-6a20f9b9-1544-4281-a58e-158c54c157ec" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 4" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/6a20f9b9-1544-4281-a58e-158c54c157ec-1679160824545.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="401.0px" datasizeheight="173.0px" datasizewidthpx="401.00000000000006" datasizeheightpx="173.0" dataX="18.0" dataY="56.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="100.0px" datasizeheight="100.0px" dataX="33.0" dataY="85.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/a402d7e2-e8d2-48ee-b721-1ee7d17cf065.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Pinjaman"   datasizewidth="66.7px" datasizeheight="18.0px" dataX="271.9" dataY="76.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Pinjaman</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Rp. 12.000.000"   datasizewidth="109.4px" datasizeheight="18.0px" dataX="271.9" dataY="95.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Rp. 12.000.000</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Sisa Pinjaman"   datasizewidth="102.3px" datasizeheight="18.0px" dataX="271.9" dataY="136.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Sisa Pinjaman</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="Rp. 5.000.000"   datasizewidth="100.5px" datasizeheight="18.0px" dataX="271.9" dataY="155.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Rp. 5.000.000</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="History Payment"   datasizewidth="101.0px" datasizeheight="26.0px" dataX="271.9" dataY="188.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">History Payment</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_1" customid="Ellipse 1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="88.0px" datasizeheight="81.0px" datasizewidthpx="88.0" datasizeheightpx="81.0" dataX="42.2" dataY="275.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_1)">\
                          <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 1" cx="44.0" cy="40.5" rx="44.0" ry="40.5">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                          <ellipse cx="44.0" cy="40.5" rx="44.0" ry="40.5">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Path_63" class="path firer commentable non-processed" customid="Person"   datasizewidth="48.5px" datasizeheight="45.4px" dataX="59.0" dataY="292.8"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="48.45998001098633" height="45.4267692565918" viewBox="59.0 292.7866151332855 48.45998001098633 45.4267692565918" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_63-6a20f" d="M83.24375092664269 315.6094697677484 C89.91092778782374 315.6094697677484 95.31048962333747 310.4080071566314 95.31048962333747 304.03998435957703 C95.31048962333747 297.76919491088677 89.91092778782374 292.7866151332855 83.24375092664269 292.7866151332855 C76.60415963744404 292.7866151332855 71.14942665796548 297.8421189331718 71.17701222994789 304.0886003744337 C71.20459481259655 310.43234417437566 76.5765770547954 315.6094697677484 83.24375092664269 315.6094697677484 Z M83.24375092664269 311.35599043602065 C79.44186243644549 311.35599043602065 76.21861031511713 308.1718972811487 76.21861031511713 304.0886003744337 C76.19102773246847 300.1025091244177 79.41427985379684 297.04003908168295 83.24375092664269 297.04003908168295 C87.10080757147094 297.04003908168295 90.26888854883447 300.0539221198769 90.26888854883447 304.03998435957703 C90.26888854883447 308.1232258829616 87.07322199948852 311.35599043602065 83.24375092664269 311.35599043602065 Z M66.05272319417422 338.2133848667145 L100.40725586313779 338.2133848667145 C105.17333004453072 338.2133848667145 107.45997905731201 336.87658423513255 107.45997905731201 334.00857693317374 C107.45997905731201 327.32457904986694 98.01027054109434 318.4288056715202 83.24375092664269 318.4288056715202 C68.47710277083912 318.4288056715202 59.0 327.32457904986694 59.0 334.00857693317374 C59.0 336.87658423513255 61.28664901278129 338.2133848667145 66.05272319417422 338.2133848667145 Z M65.19868548421344 333.9599081722881 C64.53751659942974 333.9599081722881 64.28954239563066 333.7654968588904 64.28954239563066 333.3280107458121 C64.28954239563066 329.60936296083815 71.09425850333439 322.68228500324796 83.24375092664269 322.68228500324796 C95.36566076730233 322.68228500324796 102.17043666168135 329.60936296083815 102.17043666168135 333.3280107458121 C102.17043666168135 333.7654968588904 101.9224953405537 333.9599081722881 101.26110524507138 333.9599081722881 L65.19868548421344 333.9599081722881 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_63-6a20f" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_2" customid="Ellipse 1" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="88.0px" datasizeheight="81.0px" datasizewidthpx="88.0" datasizeheightpx="81.0" dataX="170.9" dataY="275.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_2)">\
                          <ellipse id="s-Ellipse_2" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse 1" cx="44.0" cy="40.5" rx="44.0" ry="40.5">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                          <ellipse cx="44.0" cy="40.5" rx="44.0" ry="40.5">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_2" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_2_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Path_4" class="path firer click commentable non-processed" customid="Bag"   datasizewidth="44.9px" datasizeheight="49.4px" dataX="194.4" dataY="290.8"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="44.908203125" height="49.43069839477539" viewBox="194.42871260643005 290.78465032577515 44.908203125 49.43069839477539" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_4-6a20f" d="M202.59158195490505 340.21534967422485 L231.7694046712599 340.21534967422485 C236.5579918821543 340.21534967422485 239.33691239356995 337.57521272599115 239.33691239356995 332.5306849824863 L239.33691239356995 308.13368469311075 C239.33691239356995 303.0892618166155 236.5331484106402 300.4491785807525 231.1740443911868 300.4491785807525 L227.67555162649504 300.4491785807525 C227.551625024768 295.16903768634603 222.81271937253433 290.78465032577515 216.88281317304592 290.78465032577515 C210.97774775288792 290.78465032577515 206.2140040135076 295.16903768634603 206.09007471959683 300.4491785807525 L202.59158195490505 300.4491785807525 C197.23236351764288 300.4491785807525 194.42871260643005 303.0892618166155 194.42871260643005 308.13368469311075 L194.42871260643005 332.5306849824863 C194.42871260643005 337.57521272599115 197.23236351764288 340.21534967422485 202.59158195490505 340.21534967422485 Z M216.88281317304592 294.9568930048651 C220.2819374360488 294.9568930048651 222.7878812853877 297.38480598192774 222.88724978707663 300.4491785807525 L210.87837925119896 300.4491785807525 C210.97774775288792 297.38480598192774 213.4836889100431 294.9568930048651 216.88281317304592 294.9568930048651 Z M202.91413248829306 335.524305600371 C200.6314891267376 335.524305600371 199.36612508033218 334.39304634037524 199.36612508033218 332.1063981772564 L199.36612508033218 308.55783849627977 C199.36612508033218 306.2950565298984 200.6314891267376 305.16358242041963 202.91413248829306 305.16358242041963 L230.8513807860819 305.16358242041963 C233.10918067612326 305.16358242041963 234.3995551094344 306.2950565298984 234.3995551094344 308.55783849627977 L234.3995551094344 332.1063981772564 C234.3995551094344 334.39304634037524 233.10918067612326 335.524305600371 231.447026437631 335.524305600371 L202.91413248829306 335.524305600371 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-6a20f" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable non-processed" customid="Biodata"   datasizewidth="54.3px" datasizeheight="18.0px" dataX="55.1" dataY="363.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Biodata</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="richtext manualfit firer click ie-background commentable non-processed" customid="Pengajuan Pinjaman"   datasizewidth="91.7px" datasizeheight="36.0px" dataX="169.9" dataY="361.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">Pengajuan Pinjaman</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_3" customid="Ellipse 1" class="shapewrapper shapewrapper-s-Ellipse_3 non-processed"   datasizewidth="88.0px" datasizeheight="81.0px" datasizewidthpx="88.0" datasizeheightpx="81.0" dataX="304.6" dataY="275.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_3" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_3)">\
                          <ellipse id="s-Ellipse_3" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse 1" cx="44.0" cy="40.5" rx="44.0" ry="40.5">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_3" class="clipPath">\
                          <ellipse cx="44.0" cy="40.5" rx="44.0" ry="40.5">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_3" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_3_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Path_7" class="path firer click commentable non-processed" customid="Checkmark diamond"   datasizewidth="62.2px" datasizeheight="57.2px" dataX="318.5" dataY="287.4"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="62.20065689086914" height="57.20390701293945" viewBox="318.4856103306312 287.39804753705226 62.20065689086914 57.20390701293945" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_7-6a20f" d="M321.5979462160505 321.7733727777587 L343.329442620946 341.73084430383955 C347.46996245337994 345.5381322119774 351.7188683987876 345.5630493428098 355.80519517473476 341.78067856550433 L377.61782553000694 321.7235412162598 C381.7315586346559 317.94088422136997 381.7044606381639 314.0342167076527 377.56363541001735 310.2266452820964 L355.85939116771885 290.26920075767447 C351.7188683987876 286.46182779431103 347.46996245337994 286.4369403653034 343.3565376809408 290.21942589965926 L321.54381482600564 310.27647684359533 C317.43029902215216 314.05913383848514 317.484430412197 317.9658013522024 321.5979462160505 321.7733727777587 Z M325.60323154128383 318.53829592451996 C323.7900487438243 316.8709245863187 323.73591735377937 315.1540079042029 325.60323154128383 313.43680770466864 L346.7934757121724 293.9521379260828 C348.68776309503636 292.23507813517483 350.5281657536232 292.25996556418244 352.3411620835083 293.9272504970752 L373.5585996870491 313.46172213533515 C375.3715930804369 315.12909077337054 375.425789073421 316.8460101556522 373.5585996870491 318.56321035518647 L352.36826008000037 338.04785043194755 C350.5010677571312 339.76505333164766 348.60647497855473 339.7152190699829 346.8205707721672 338.0727675627799 L325.60323154128383 318.53829592451996 Z M346.6850895991987 327.8202430789969 C347.6593312871227 327.8202430789969 348.49839719779084 327.3723233601778 349.06680615823444 326.5761578462009 L361.16382691753216 309.1816027778775 C361.5154607155312 308.6589397670589 361.8403136587397 308.06181158132733 361.8403136587397 307.4893170090098 C361.8403136587397 306.27014620688027 360.64961101357534 305.448890751454 359.3776143789349 305.448890751454 C358.5656435282616 305.448890751454 357.8349666670644 305.8471463190594 357.26655477012355 306.6931460947011 L346.5770118184348 322.47016138632216 L341.5432330188459 316.57222143490964 C340.89384133763315 315.8009676514333 340.24414426070786 315.52717623052484 339.4321734100346 315.52717623052484 C338.1062979241115 315.52717623052484 337.07786317970067 316.4977562599968 337.07786317970067 317.7418414927928 C337.07786317970067 318.3392531959428 337.3214250699303 318.8865498201754 337.78144791740027 319.409212830994 L344.1682001994043 326.5761578462009 C344.8988799970987 327.447074752675 345.6837528512799 327.8202430789969 346.6850895991987 327.8202430789969 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-6a20f" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="richtext autofit firer click ie-background commentable non-processed" customid="Status Pinjaman"   datasizewidth="116.5px" datasizeheight="18.0px" dataX="289.3" dataY="363.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Status Pinjaman</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer click commentable non-processed" customid="Logout"   datasizewidth="41.2px" datasizeheight="46.9px" dataX="352.3" dataY="857.6"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="41.15625" height="46.85006332397461" viewBox="352.3046875 857.5708690302802 41.15625 46.85006332397461" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-6a20f" d="M357.95088195913354 904.4209302289053 L376.45307234527354 904.4209302289053 C380.17075007971295 904.4209302289053 382.09916923142686 901.9972206005768 382.09916923142686 897.3228949151926 L382.09916923142686 887.5852238385969 L378.6939979074229 887.5852238385969 L378.6939979074229 897.0633863951545 C378.6939979074229 899.0759215435444 377.84285391656135 900.1794414692572 376.15756347875606 900.1794414692572 L358.2288380253242 900.1794414692572 C356.5436670730753 900.1794414692572 355.70977902915143 899.0759215435444 355.70977902915143 897.0633863951545 L355.70977902915143 864.9283618802411 C355.70977902915143 862.9158772006533 356.5436670730753 861.8122583972875 358.2288380253242 861.8122583972875 L376.15756347875606 861.8122583972875 C377.84285391656135 861.8122583972875 378.6939979074229 862.9158772006533 378.6939979074229 864.9283618802411 L378.6939979074229 874.4281667980733 L382.09916923142686 874.4281667980733 L382.09916923142686 864.6686823842615 C382.09916923142686 860.0161690061178 380.17075007971295 857.5708690302802 376.45307234527354 857.5708690302802 L357.95088195913354 857.5708690302802 C354.23308494586024 857.5708690302802 352.3046875 860.0161690061178 352.3046875 864.6686823842615 L352.3046875 897.3228949151926 C352.3046875 901.9972206005768 354.23308494586024 904.4209302289053 357.95088195913354 904.4209302289053 Z M369.13908277983 882.9758957903616 L386.65079330551134 882.9758957903616 L389.2220166360908 882.8244770245936 L387.95379942175737 884.1660840388257 L385.36518164022164 887.1957179843096 C385.05247843004634 887.5418907071968 384.8789275199629 888.0394842558031 384.8789275199629 888.5373249985417 C384.8789275199629 889.5110906642356 385.4695516535181 890.3334375641614 386.26870743747133 890.3334375641614 C386.685582207424 890.3334375641614 386.9982887251579 890.1170191012932 387.29360079193555 889.7491777527548 L392.92250002687234 882.4997236732742 C393.32198034586867 881.9804635589678 393.4609375 881.5042893819292 393.4609375 880.9850292676228 C393.4609375 880.4657691533165 393.32198034586867 879.9895949762779 392.92250002687234 879.4703348619715 L387.29360079193555 872.1992131868152 C386.9982887251579 871.8314223070789 386.685582207424 871.6366683499597 386.26870743747133 871.6366683499597 C385.4695516535181 871.6366683499597 384.8789275199629 872.415632679659 384.8789275199629 873.4110669710038 C384.8789275199629 873.8872401180669 385.05247843004634 874.4065002323732 385.36518164022164 874.752673985236 L387.95379942175737 877.8039744964199 L389.23941108704713 879.145581510652 L386.65079330551134 878.9724941192329 L369.13908277983 878.9724941192329 C368.28774033544926 878.9724941192329 367.5581590477627 879.88150934191 367.5581590477627 880.9850292676228 C367.5581590477627 882.0885491933357 368.28774033544926 882.9758957903616 369.13908277983 882.9758957903616 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-6a20f" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_3" class="path firer click commentable non-processed" customid="Home"   datasizewidth="51.5px" datasizeheight="41.8px" dataX="188.3" dataY="860.1"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="51.49802017211914" height="41.81520080566406" viewBox="188.25098967552185 860.0882996403043 51.49802017211914 41.81520080566406" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-6a20f" d="M188.25098967552185 879.831131681301 C188.25098967552185 880.8469978161472 189.09314395563825 881.7259637261217 190.44059994184528 881.7259637261217 C191.0932716506591 881.7259637261217 191.68277450660392 881.3939353243419 192.20913249698418 881.0032338837165 L194.60928161889984 879.1279602249981 L194.60928161889984 897.2937650749291 C194.60928161889984 900.1844597816839 196.4830955954871 901.903499492294 199.70436670053397 901.903499492294 L228.1903507357651 901.903499492294 C231.39070948034893 901.903499492294 233.28553290886958 900.1844597816839 233.28553290886958 897.2937650749291 L233.28553290886958 879.0303950768136 L235.81204029706993 881.0032338837165 C236.31724948070053 881.3939353243419 236.90677518169718 881.7259637261217 237.5595405552236 881.7259637261217 C238.80159861021784 881.7259637261217 239.74901032447815 881.0032338837165 239.74901032447815 879.8702463340445 C239.74901032447815 879.2061895304852 239.47544539759096 878.6788082889317 238.92784036673808 878.2489943150237 L233.28553290886958 873.8346084985104 L233.28553290886958 865.5135728230341 C233.28553290886958 864.6345846587192 232.6749257940262 864.0876704645955 231.72751407976588 864.0876704645955 L228.82203926445519 864.0876704645955 C227.89570896404155 864.0876704645955 227.26402043535148 864.6345846587192 227.26402043535148 865.5135728230341 L227.26402043535148 869.1467125984103 L217.0106585741624 861.1577265193238 C215.17907710267667 859.7318241608851 212.86313027286783 859.7318241608851 211.0313089283377 861.1577265193238 L189.09314395563825 878.2489943150237 C188.52467339667868 878.6788082889317 188.25098967552185 879.26486044987 188.25098967552185 879.831131681301 Z M220.06345655984006 885.222268979917 C220.06345655984006 884.304188417199 219.4320056196892 883.7183587996657 218.44243564674582 883.7183587996657 L209.5997717287987 883.7183587996657 C208.61019947135014 883.7183587996657 207.95743181331852 884.304188417199 207.95743181331852 885.222268979917 L207.95743181331852 898.0164927978733 L200.82022640460644 898.0164927978733 C199.51486014192693 898.0164927978733 198.79904356754855 897.3326571842676 198.79904356754855 896.1021066058723 L198.79904356754855 875.866120344259 L213.09477224510604 864.7322600188756 C213.6843002306079 864.2634638585365 214.3579071449366 864.2634638585365 214.94743513043846 864.7322600188756 L229.07476036603492 875.7487763860285 L229.07476036603492 896.1021066058723 C229.07476036603492 897.3326571842676 228.35875531997874 898.0164927978733 227.05345759245478 898.0164927978733 L220.06345655984006 898.0164927978733 L220.06345655984006 885.222268979917 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-6a20f" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;