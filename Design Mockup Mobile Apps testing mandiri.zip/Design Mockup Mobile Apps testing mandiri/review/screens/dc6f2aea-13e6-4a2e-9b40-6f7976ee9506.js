var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1679160824545.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-dc6f2aea-13e6-4a2e-9b40-6f7976ee9506" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 3" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/dc6f2aea-13e6-4a2e-9b40-6f7976ee9506-1679160824545.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="390.0px" datasizeheight="191.0px" datasizewidthpx="390.0" datasizeheightpx="191.0" dataX="19.0" dataY="90.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Fintect PT XYZ"   datasizewidth="108.5px" datasizeheight="18.0px" dataX="159.8" dataY="239.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Fintect PT XYZ</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="127.0px" datasizeheight="123.0px" dataX="150.5" dataY="96.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/12f27269-2628-4422-8f90-088afc1dee31.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="Save Password"   datasizewidth="300.0px" datasizeheight="45.0px" dataX="64.0" dataY="528.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Save Password</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="64.0" dataY="317.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Username"/></div></div>  </div></div></div>\
      <div id="s-Input_3" class="password firer commentable non-processed" customid="Input 3"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="64.0" dataY="386.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="password"  value="" maxlength="100"  tabindex="-1" placeholder="Password"/></div></div></div></div></div>\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="Top Nav Default" datasizewidth="428.0px" datasizeheight="90.0px" dataX="0.0" dataY="0.0" >\
        <div id="s-Panel_1" class="panel default firer click ie-background commentable non-processed" customid="Panel 1"  datasizewidth="428.0px" datasizeheight="90.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Top_Bar-2" class="group firer ie-background commentable non-processed" customid="Top Nav Default" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Rectangle_19" class="rectangle manualfit firer commentable non-processed" customid="Base"   datasizewidth="428.0px" datasizeheight="90.0px" datasizewidthpx="428.0" datasizeheightpx="90.0" dataX="0.0" dataY="0.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_19_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Path_10" class="path firer click commentable non-processed" customid="Chevron"   datasizewidth="11.9px" datasizeheight="20.8px" dataX="12.0" dataY="55.0"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="11.920833587646484" height="20.789018630981445" viewBox="12.000000000000021 55.0 11.920833587646484 20.789018630981445" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_10-dc6f2" d="M21.56464368687122 75.39061743021011 C21.821343439678834 75.64841848611832 22.147917596683968 75.78901869058609 22.53281961928969 75.78901869058609 C23.302621766023883 75.78901869058609 23.920833352554702 75.17971807718277 23.920833352554702 74.40621763467789 C23.920833352554702 74.01951795816422 23.757595634460472 73.6680184006691 23.489249673000625 73.39841848611832 L15.324313864597077 65.38281828165054 L23.489249673000625 57.390627920627594 C23.757595634460472 57.12109810113907 23.920833352554702 56.75780802965164 23.920833352554702 56.38280802965164 C23.920833352554702 55.60937803983688 23.302621766023883 55.0 22.53281961928969 55.0 C22.147917596683968 55.0 21.821343439678834 55.14062803983688 21.56464368687122 55.3984380364418 L12.489898730433286 64.30471807718277 C12.163294909721218 64.60941797494888 12.011664481495723 64.98441797494888 12.000000000000021 65.39451795816422 C12.000000000000021 65.80471807718277 12.163294909721218 66.15621763467789 12.489898730433286 66.47261816263199 L21.56464368687122 75.39061743021011 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-dc6f2" fill="#0A84FF" fill-opacity="1.0"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_54" class="richtext manualfit firer click ie-background commentable non-processed" customid="Left Title"   datasizewidth="99.5px" datasizeheight="22.0px" dataX="31.0" dataY="53.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_54_0">Login</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_56" class="richtext manualfit firer ie-background commentable non-processed" customid="Title"   datasizewidth="132.4px" datasizeheight="44.0px" dataX="148.0" dataY="54.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_56_0">Set Password</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
\
                <div id="s-statusBar_7" class="group firer ie-background commentable non-processed" customid="Status Bar" datasizewidth="984.0px" datasizeheight="22.0px" >\
                  <div id="s-Text_15" class="richtext manualfit firer pageload ie-background commentable non-processed" customid="Clock"   datasizewidth="50.0px" datasizeheight="20.0px" dataX="11.0" dataY="13.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Text_15_0">4:02</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Path_83" class="path firer commentable non-processed" customid="Signal Icon"   datasizewidth="17.0px" datasizeheight="10.7px" dataX="335.0" dataY="18.0"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="17.0" height="10.66670036315918" viewBox="335.0 18.0 17.0 10.66670036315918" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_83-dc6f2" d="M351.0 18.0 L350.0 18.0 C349.447021484375 18.0 349.0 18.44770050048828 349.0 19.0 L349.0 27.66670036315918 C349.0 28.2189998626709 349.447021484375 28.66670036315918 350.0 28.66670036315918 L351.0 28.66670036315918 C351.552001953125 28.66670036315918 352.0 28.2189998626709 352.0 27.66670036315918 L352.0 19.0 C352.0 18.44770050048828 351.552001953125 18.0 351.0 18.0 Z M345.3330078125 20.33340072631836 L346.3330078125 20.33340072631836 C346.885009765625 20.33340072631836 347.3330078125 20.78110122680664 347.3330078125 21.33340072631836 L347.3330078125 27.66670036315918 C347.3330078125 28.2189998626709 346.885009765625 28.66670036315918 346.3330078125 28.66670036315918 L345.3330078125 28.66670036315918 C344.781005859375 28.66670036315918 344.3330078125 28.2189998626709 344.3330078125 27.66670036315918 L344.3330078125 21.33340072631836 C344.3330078125 20.78110122680664 344.781005859375 20.33340072631836 345.3330078125 20.33340072631836 Z M341.666015625 22.66670036315918 L340.666015625 22.66670036315918 C340.114013671875 22.66670036315918 339.666015625 23.11440086364746 339.666015625 23.66670036315918 L339.666015625 27.66670036315918 C339.666015625 28.2189998626709 340.114013671875 28.66670036315918 340.666015625 28.66670036315918 L341.666015625 28.66670036315918 C342.218017578125 28.66670036315918 342.666015625 28.2189998626709 342.666015625 27.66670036315918 L342.666015625 23.66670036315918 C342.666015625 23.11440086364746 342.218017578125 22.66670036315918 341.666015625 22.66670036315918 Z M337.0 24.66670036315918 L336.0 24.66670036315918 C335.447021484375 24.66670036315918 335.0 25.11440086364746 335.0 25.66670036315918 L335.0 27.66670036315918 C335.0 28.2189998626709 335.447021484375 28.66670036315918 336.0 28.66670036315918 L337.0 28.66670036315918 C337.552001953125 28.66670036315918 338.0 28.2189998626709 338.0 27.66670036315918 L338.0 25.66670036315918 C338.0 25.11440086364746 337.552001953125 24.66670036315918 337.0 24.66670036315918 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_83-dc6f2" fill="#000000" fill-opacity="1.0"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Path_84" class="path firer commentable non-processed" customid="Wifi Icon"   datasizewidth="15.3px" datasizeheight="11.0px" dataX="360.0" dataY="18.0"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="15.27301025390625" height="10.965625762939453" viewBox="360.0 17.999999523162842 15.27301025390625 10.965625762939453" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_84-dc6f2" d="M367.6369934082031 20.277324199676514 C369.8529968261719 20.277425289154053 371.9840087890625 21.12892484664917 373.5899963378906 22.65562391281128 C373.71099853515625 22.77352476119995 373.90399169921875 22.772023677825928 374.02301025390625 22.652324199676514 L375.17901611328125 21.485623836517334 C375.2400207519531 21.42492437362671 375.27301025390625 21.34272527694702 375.27301025390625 21.257123470306396 C375.2720031738281 21.171523571014404 375.2380065917969 21.089725017547607 375.177001953125 21.029624462127686 C370.9620056152344 16.99012517929077 364.31201171875 16.99012517929077 360.0970153808594 21.029624462127686 C360.0360107421875 21.08962392807007 360.0010070800781 21.171424388885498 360.0 21.25702428817749 C360.0 21.342624187469482 360.03302001953125 21.42492437362671 360.093994140625 21.485623836517334 L361.25 22.652324199676514 C361.3690185546875 22.772223949432373 361.56201171875 22.773725032806396 361.6830139160156 22.65562391281128 C363.28900146484375 21.12882375717163 365.4210205078125 20.277324199676514 367.6369934082031 20.277324199676514 Z M367.6369934082031 24.0730242729187 C368.85400390625 24.072925090789795 370.02801513671875 24.525424480438232 370.9309997558594 25.342624187469482 C371.0530090332031 25.458625316619873 371.2449951171875 25.456124782562256 371.364013671875 25.337024211883545 L372.5190124511719 24.170323848724365 C372.58001708984375 24.109124660491943 372.614013671875 24.026124477386475 372.6130065917969 23.93982458114624 C372.61199951171875 23.853623867034912 372.5760192871094 23.771323680877686 372.5140075683594 23.711324214935303 C369.7660217285156 21.154923915863037 365.510009765625 21.154923915863037 362.7619934082031 23.711324214935303 C362.70001220703125 23.771323680877686 362.66400146484375 23.853623867034912 362.66400146484375 23.939923763275146 C362.6629943847656 24.02622365951538 362.697021484375 24.10922384262085 362.75799560546875 24.170323848724365 L363.9120178222656 25.337024211883545 C364.031005859375 25.456124782562256 364.2229919433594 25.458625316619873 364.3450012207031 25.342624187469482 C365.24700927734375 24.52602529525757 366.4200134277344 24.073523998260498 367.6369934082031 24.0730242729187 Z M369.95001220703125 26.626824855804443 C369.9519958496094 26.713325023651123 369.9179992675781 26.79672384262085 369.85601806640625 26.85732412338257 L367.8590087890625 28.873023509979248 C367.8000183105469 28.932223796844482 367.7200012207031 28.965625286102295 367.6369934082031 28.965625286102295 C367.55401611328125 28.965625286102295 367.4739990234375 28.932223796844482 367.4150085449219 28.873023509979248 L365.4179992675781 26.85732412338257 C365.35601806640625 26.79672384262085 365.322021484375 26.713223934173584 365.3240051269531 26.626723766326904 C365.3260192871094 26.540223598480225 365.3630065917969 26.45832395553589 365.427001953125 26.400325298309326 C366.7030029296875 25.32142400741577 368.5710144042969 25.32142400741577 369.8470153808594 26.400325298309326 C369.9110107421875 26.458425045013428 369.947998046875 26.540324687957764 369.95001220703125 26.626824855804443 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_84-dc6f2" fill="#000000" fill-opacity="1.0"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Union_8" class="path firer commentable non-processed" customid="Battery Icon"   datasizewidth="23.8px" datasizeheight="11.3px" dataX="383.0" dataY="18.0"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="23.8280029296875" height="11.33331298828125" viewBox="383.0 18.0 23.8280029296875 11.33331298828125" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Union_8-dc6f2" d="M405.5 21.5 L405.5 25.5 C406.30499267578125 25.16119384765625 406.8280029296875 24.37310791015625 406.8280029296875 23.5 C406.8280029296875 22.626800537109375 406.30499267578125 21.838714599609375 405.5 21.5 Z M386.3330078125 20.0 C385.59698486328125 20.0 385.0 20.596899032592773 385.0 21.33329963684082 L385.0 25.8125 C385.0 26.54889678955078 385.59698486328125 27.145797729492188 386.3330078125 27.145797729492188 L399.1669921875 27.145797729492188 C399.90301513671875 27.145797729492188 400.5 26.54889678955078 400.5 25.8125 L400.5 21.33329963684082 C400.5 20.596899032592773 399.90301513671875 20.0 399.1669921875 20.0 Z M402.3330078125 19.0 C403.25390625 19.0 404.0 19.7462158203125 404.0 20.666595458984375 L404.0 26.666595458984375 C404.0 27.587127685546875 403.25390625 28.33331298828125 402.3330078125 28.33331298828125 L385.6669921875 28.33331298828125 C384.74609375 28.33331298828125 384.0 27.587127685546875 384.0 26.666595458984375 L384.0 20.666595458984375 C384.0 19.7462158203125 384.74609375 19.0 385.6669921875 19.0 Z M385.6669921875 18.0 C384.19390869140625 18.0 383.0 19.19378662109375 383.0 20.666595458984375 L383.0 26.666595458984375 C383.0 28.139495849609375 384.19390869140625 29.33331298828125 385.6669921875 29.33331298828125 L402.3330078125 29.33331298828125 C403.80609130859375 29.33331298828125 405.0 28.139495849609375 405.0 26.666595458984375 L405.0 20.666595458984375 C405.0 19.19378662109375 403.80609130859375 18.0 402.3330078125 18.0 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Union_8-dc6f2" fill="#000000" fill-opacity="1.0"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="password firer commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="64.0" dataY="452.4" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="password"  value="" maxlength="100"  tabindex="-1" placeholder="Re-Enter Password"/></div></div></div></div></div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;